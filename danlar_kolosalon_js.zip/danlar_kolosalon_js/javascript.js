"use strict";

function celkovaCena() {
  var total = 0;
  var polozky = document.getElementsByClassName("input0");
  var kusy = document.getElementsByClassName("input1");
  var dny = document.getElementById("days");
  var dnyChoose = dny.options[dny.selectedIndex].value;
  var mntNumb = document.getElementById("mountainPcs");
  var kidNumb = document.getElementById("kidsPcs");
  var roadNumb = document.getElementById("roadPcs");
  var gravelNumb = document.getElementById("gravelPcs");
  var radioBtn = document.querySelector(
    'input[name="radioButton0"]:checked'
  ).value;
  var odhadCeny = parseInt(document.querySelector("#sumCustomer").value);

  for (var i = 0; i < 4; i++) {
    if (polozky[i].checked) {
      if (mntNumb != 0 || kidNumb != 0 || roadNumb != 0 || gravelNumb != 0) {
        //total += (polozky[i].value*);
        total += polozky[i].value * kusy[i].value;
      }

      total = total * dnyChoose;
    }
  }
  total = total + parseFloat(radioBtn * total);

  document.getElementById("celkovaCenaJe").innerHTML = total + " Kč";

  if (total <= odhadCeny) {
    document.getElementById("output").textContent = "Máte na to finance.";
  } else {
    document.getElementById("output").textContent = "Je mi líto, není dostatek peněz.";
  }
}

//backwards compatibility for event listener submit button
var calcButton = document.getElementById("calculate"); //sButton HTML element is assign JS value of submitButton
if (calcButton.addEventListener) {
  //now you can add event listener
  calcButton.addEventListener("click", celkovaCena, false); //event is click, action is calctotal, false for bwc
} else if (calcButton.attachEvent) {
  calcButton.attachEvent("onclick", celkovaCena);
}

function validateemail() {
  var x = document.myform.email.value;
  var atposition = x.indexOf("@");
  var dotposition = x.lastIndexOf(".");
  if (
    atposition < 1 ||
    dotposition < atposition + 2 ||
    dotposition + 2 >= x.length
  ) {
    alert("Prosim, zadej e-mail správně!");
    return false;
  }
}
